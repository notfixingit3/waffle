--
-- PostgreSQL database dump
--

\restrict u0n6Mj7JYZMm6dJ7bVQNkSF35heyaC1wjTvXuxwaXLmHdQWdStMk1EBCrh7a9dC

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_events; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.activity_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    waffle_id uuid NOT NULL,
    event_type text NOT NULL,
    message text NOT NULL,
    instagram_handle text,
    spot_numbers integer[],
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.activity_events OWNER TO syrup;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text,
    password_hash text NOT NULL,
    display_name text,
    role text DEFAULT 'admin'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    timezone text DEFAULT 'UTC'::text NOT NULL,
    last_login_ip text,
    first_name text,
    last_name text,
    social_links jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT admins_role_check CHECK ((role = ANY (ARRAY['super_admin'::text, 'admin'::text, 'waffle_manager'::text])))
);


ALTER TABLE public.admins OWNER TO syrup;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    action text NOT NULL,
    target_type text NOT NULL,
    target_id text DEFAULT ''::text NOT NULL,
    details text DEFAULT ''::text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO syrup;

--
-- Name: buyer_stats; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.buyer_stats (
    instagram_handle text NOT NULL,
    total_waffles_entered integer DEFAULT 0 NOT NULL,
    total_wins integer DEFAULT 0 NOT NULL,
    total_losses integer DEFAULT 0 NOT NULL,
    total_spots_claimed integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.buyer_stats OWNER TO syrup;

--
-- Name: login_history; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.login_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    user_agent text DEFAULT ''::text,
    browser text DEFAULT ''::text,
    os text DEFAULT ''::text,
    device_type text DEFAULT 'unknown'::text NOT NULL,
    ip_org text DEFAULT ''::text NOT NULL,
    ip_country text DEFAULT ''::text NOT NULL,
    ip_city text DEFAULT ''::text NOT NULL,
    ip_asn text DEFAULT ''::text NOT NULL,
    whois_server text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT login_history_device_type_check CHECK ((device_type = ANY (ARRAY['mobile'::text, 'desktop'::text, 'tablet'::text, 'unknown'::text])))
);


ALTER TABLE public.login_history OWNER TO syrup;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.password_reset_tokens OWNER TO syrup;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO syrup;

--
-- Name: spots; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.spots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    waffle_id uuid NOT NULL,
    number integer NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    claimed_by_handle text,
    claimed_at timestamp with time zone,
    paid_at timestamp with time zone,
    CONSTRAINT spots_status_check CHECK ((status = ANY (ARRAY['available'::text, 'pending'::text, 'paid'::text, 'winner'::text, 'loser'::text])))
);


ALTER TABLE public.spots OWNER TO syrup;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


ALTER TABLE public.system_settings OWNER TO syrup;

--
-- Name: users; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    instagram_handle text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO syrup;

--
-- Name: waffles; Type: TABLE; Schema: public; Owner: syrup
--

CREATE TABLE public.waffles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    title text NOT NULL,
    description text,
    image_url text,
    total_spots integer NOT NULL,
    spot_price integer NOT NULL,
    payment_info text,
    status text DEFAULT 'active'::text NOT NULL,
    winning_spot_number integer,
    winning_instagram_handle text,
    instagram_media_links jsonb DEFAULT '[]'::jsonb,
    archived boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    item_count integer DEFAULT 1 NOT NULL,
    winning_spot_numbers jsonb DEFAULT '[]'::jsonb,
    winning_instagram_handles jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT waffles_status_check CHECK ((status = ANY (ARRAY['active'::text, 'completed'::text])))
);


ALTER TABLE public.waffles OWNER TO syrup;

--
-- Data for Name: activity_events; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.activity_events (id, waffle_id, event_type, message, instagram_handle, spot_numbers, created_at) FROM stdin;
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.admins (id, username, email, password_hash, display_name, role, active, last_login_at, created_at, updated_at, timezone, last_login_ip, first_name, last_name, social_links) FROM stdin;
0e123f62-c80b-4596-b483-43eda878ca34	admin	admin@example.com	$2a$10$wQyW6bL3riJWfOhlTN6eFOO.7Wu8XSgpbWYczoYwP2pt7vIO7X.8u	Admin	super_admin	t	2026-06-04 07:39:59.329505+00	2026-05-31 05:10:45.321651+00	2026-05-31 06:17:31.579121+00	UTC	192.168.107.1	Admin	User	[{"handle": "adminuser", "platform": "instagram"}]
cfe46199-563a-4583-b192-6b0cc9ca6bc8	test-gs-cfe46199	test-gs-cfe46199@example.com	test-hash	\N	admin	t	\N	2026-05-31 12:38:52.177749+00	2026-05-31 12:38:52.177749+00	UTC	\N	\N	\N	[]
0da768f7-45ec-4514-ad28-92dc9dcbfac6	test-gs-0da768f7	test-gs-0da768f7@example.com	test-hash	\N	admin	t	\N	2026-06-04 07:33:28.420371+00	2026-06-04 07:33:28.420371+00	UTC	\N	\N	\N	[]
ed72e3f0-91f5-4745-b8f8-6cc77413ff3b	test-gs-ed72e3f0	test-gs-ed72e3f0@example.com	test-hash	\N	admin	t	\N	2026-05-31 15:55:23.67139+00	2026-05-31 15:55:23.67139+00	UTC	\N	\N	\N	[]
4ae3b8b2-4d6b-4f1b-b41a-87763707aea6	newuser2	new2@example.com	$2a$10$c/g5fFkDjqqmdlHOeswanOyzGZ1BxzLaELTAdUdTvJOSPv7pi0Gi2	\N	admin	t	\N	2026-05-31 06:15:45.898848+00	2026-05-31 06:15:45.898848+00	UTC	\N	New	User	[]
7807dfa8-61cd-4643-b01e-d15a46c9433a	testadmin	updated@example.com	$2a$10$EcpSfd7glHbNO8bqoqinGePh6wn7rL0RtjAxpQa95xO7lJBXlsdLe	\N	admin	t	\N	2026-05-31 06:02:22.388433+00	2026-05-31 06:17:31.711552+00	UTC	\N	Updated	Name	[{"handle": "updated", "platform": "tiktok"}]
b0b9f4b1-160c-461d-a5fa-475e52a5379a	profiletest	profile@example.com	$2a$10$B9ynYGl3RLNYcKCpGQ80Xec6LFM90ikU7EJHEc8OLi/504GTT4YBe	\N	admin	t	\N	2026-05-31 06:17:31.791415+00	2026-05-31 06:17:31.791415+00	UTC	\N	Profile	Test	[]
5353914e-f873-4172-a052-0e9c49331cf1	test-gs-5353914e	test-gs-5353914e@example.com	test-hash	\N	admin	t	\N	2026-05-31 08:35:32.331134+00	2026-05-31 08:35:32.331134+00	UTC	\N	\N	\N	[]
90248f0e-c2c2-444f-96df-6c38c2ea0a7f	test-gs-90248f0e	test-gs-90248f0e@example.com	test-hash	\N	admin	t	\N	2026-05-31 09:55:11.971743+00	2026-05-31 09:55:11.971743+00	UTC	\N	\N	\N	[]
25d0b065-478a-47bb-8efe-a4af7952dfea	test-gs-25d0b065	test-gs-25d0b065@example.com	test-hash	\N	admin	t	\N	2026-05-31 12:57:22.1749+00	2026-05-31 12:57:22.1749+00	UTC	\N	\N	\N	[]
9a810512-9e97-48ae-bf52-175edf839733	test-gs-9a810512	test-gs-9a810512@example.com	test-hash	\N	admin	t	\N	2026-05-31 16:01:00.407073+00	2026-05-31 16:01:00.407074+00	UTC	\N	\N	\N	[]
f3d338e9-255a-4e54-964f-3769d0f68ce3	test-gs-f3d338e9	test-gs-f3d338e9@example.com	test-hash	\N	admin	t	\N	2026-06-04 06:35:27.28664+00	2026-06-04 06:35:27.286641+00	UTC	\N	\N	\N	[]
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.audit_log (id, admin_id, action, target_type, target_id, details, ip_address, created_at) FROM stdin;
17989dde-347d-4be2-8f2a-234669efb6d3	0e123f62-c80b-4596-b483-43eda878ca34	create_admin	admin	7807dfa8-61cd-4643-b01e-d15a46c9433a	created admin 'testadmin' with role admin	192.168.97.1	2026-05-31 06:02:22.419973+00
89e7ac3d-763e-4d53-8803-16374f2af834	0e123f62-c80b-4596-b483-43eda878ca34	update_admin_profile	admin	7807dfa8-61cd-4643-b01e-d15a46c9433a	updated profile for admin 'testadmin'	192.168.97.1	2026-05-31 06:02:46.429586+00
557c99a3-5c9b-425a-9981-caf648bae19e	0e123f62-c80b-4596-b483-43eda878ca34	create_admin	admin	4ae3b8b2-4d6b-4f1b-b41a-87763707aea6	created admin 'newuser2' with role admin	192.168.97.1	2026-05-31 06:15:45.906418+00
7cd0ba34-8cc8-46aa-b81f-755df3e1a53a	0e123f62-c80b-4596-b483-43eda878ca34	update_admin_profile	admin	7807dfa8-61cd-4643-b01e-d15a46c9433a	updated profile for admin 'testadmin'	192.168.97.1	2026-05-31 06:17:31.719677+00
a8a04c11-0635-4d93-a70f-8063688763c0	0e123f62-c80b-4596-b483-43eda878ca34	create_admin	admin	b0b9f4b1-160c-461d-a5fa-475e52a5379a	created admin 'profiletest' with role admin	192.168.97.1	2026-05-31 06:17:31.793644+00
913147e9-71ba-4272-bd79-0a5c9b6f3f9b	5353914e-f873-4172-a052-0e9c49331cf1	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-05-31 08:35:32.343906+00
8c0e0712-d21a-40f0-a756-d1fabd06fca1	90248f0e-c2c2-444f-96df-6c38c2ea0a7f	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-05-31 09:55:11.980207+00
41a5556a-ab58-47a5-9b2a-63748eb18eb1	cfe46199-563a-4583-b192-6b0cc9ca6bc8	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-05-31 12:38:52.197426+00
20df13e4-2e9a-4ad7-a291-cdeb1509d3ac	25d0b065-478a-47bb-8efe-a4af7952dfea	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-05-31 12:57:22.182256+00
5bdbc9fe-df72-4383-9272-26c64d5028fd	ed72e3f0-91f5-4745-b8f8-6cc77413ff3b	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-05-31 15:55:23.713807+00
475ebf03-d1ab-4bd6-9530-c4218b540b98	9a810512-9e97-48ae-bf52-175edf839733	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-05-31 16:01:00.420427+00
066e3bff-8ada-4a8d-9866-bd03e7b478af	f3d338e9-255a-4e54-964f-3769d0f68ce3	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-06-04 06:35:27.29587+00
f9d705d5-7355-4cae-a116-3723e4bc2fbf	0da768f7-45ec-4514-ad28-92dc9dcbfac6	update_setting	settings		Updated jwt_expiration_hours to 48	192.0.2.1	2026-06-04 07:33:28.42463+00
\.


--
-- Data for Name: buyer_stats; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.buyer_stats (instagram_handle, total_waffles_entered, total_wins, total_losses, total_spots_claimed, updated_at) FROM stdin;
buyer_a	135	27	108	135	2026-06-04 07:37:38.900103+00
buyer_b	90	9	81	90	2026-06-04 07:37:38.903996+00
buyer_5	1	1	0	1	2026-06-04 07:37:38.977487+00
buyer_6	1	0	1	1	2026-06-04 07:37:38.980057+00
buyer_1	3	1	2	3	2026-06-04 07:37:39.03339+00
buyer_2	3	2	1	3	2026-06-04 07:37:39.035464+00
buyer_3	3	1	2	3	2026-06-04 07:37:39.037608+00
buyer_4	3	2	1	3	2026-06-04 07:37:39.040048+00
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.login_history (id, admin_id, ip_address, user_agent, browser, os, device_type, ip_org, ip_country, ip_city, ip_asn, whois_server, created_at) FROM stdin;
0c32676f-d770-4005-92e3-a4df1c0e0350	0e123f62-c80b-4596-b483-43eda878ca34	192.168.107.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	Chrome	macOS	desktop						2026-06-04 07:39:59.329505+00
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.password_reset_tokens (id, admin_id, token_hash, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.schema_migrations (version, dirty) FROM stdin;
13	f
\.


--
-- Data for Name: spots; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.spots (id, waffle_id, number, status, claimed_by_handle, claimed_at, paid_at) FROM stdin;
5e699434-1baf-4a9d-aaf2-93f2a7310f2c	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	10	available	\N	\N	\N
193194a4-5cef-4a07-baf7-0e15d324586f	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	2	available	\N	\N	\N
2e63ac42-c235-41fc-a8c1-592db4dac8d7	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	5	available	\N	\N	\N
1249f16e-d84c-41fa-b8c3-d7ad4d48c6d5	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	8	available	\N	\N	\N
533aed66-baff-4b58-91ce-24b88b9bbb5a	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	6	available	\N	\N	\N
df6bfdba-0b09-421c-9740-cde38d9c2718	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	4	available	\N	\N	\N
e3b2dcaa-7687-4ca2-8c71-2933a27f8cbf	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	1	available	\N	\N	\N
37907e4b-7e6b-4a71-b427-d8a51a02977c	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	3	available	\N	\N	\N
d9547d02-6df9-4a7d-809e-e315fac31449	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	9	available	\N	\N	\N
6e8c5510-1a0b-4a2b-b8b4-131c59b94011	f1d6f95c-972b-4393-a0fe-70ab7bea71fa	7	available	\N	\N	\N
a100c429-05ae-468e-9b7f-b325740eeb21	1ad9926e-f4b2-4371-8700-4eac8db8c58e	5	winner	buyer_b	2026-05-31 09:55:13.860565+00	2026-05-31 09:55:13.877664+00
1bae4416-3c39-4eca-98b2-6b656cde5c1a	439043a0-28ca-4b4e-9869-e0c19bafae22	2	available	\N	\N	\N
3abf2005-4112-4dbd-a94c-5cdc4e52786b	439043a0-28ca-4b4e-9869-e0c19bafae22	3	available	\N	\N	\N
d3a8b74b-d330-47b3-9b56-6f404bb0d6cc	439043a0-28ca-4b4e-9869-e0c19bafae22	1	pending	test_buyer	2026-05-31 09:55:13.904313+00	\N
2110892e-328d-459e-bcba-feffa6a589ab	183bf8c4-5793-4401-be77-1ab355eca74e	1	paid	buyer_a	2026-05-31 08:35:34.413448+00	2026-05-31 08:35:34.427997+00
cdce00ff-0d36-4a3f-adc5-a8649e549394	183bf8c4-5793-4401-be77-1ab355eca74e	2	paid	buyer_a	2026-05-31 08:35:34.414093+00	2026-05-31 08:35:34.42943+00
1b609dd6-7d83-4de6-8cdc-7079d09d586d	183bf8c4-5793-4401-be77-1ab355eca74e	3	paid	buyer_a	2026-05-31 08:35:34.414775+00	2026-05-31 08:35:34.433127+00
22ce601c-6d3d-4d1a-94e7-6ac3f92d5d58	183bf8c4-5793-4401-be77-1ab355eca74e	4	paid	buyer_b	2026-05-31 08:35:34.424336+00	2026-05-31 08:35:34.435145+00
a7705e76-0d67-4559-983e-5b4dea5286a1	183bf8c4-5793-4401-be77-1ab355eca74e	5	paid	buyer_b	2026-05-31 08:35:34.424912+00	2026-05-31 08:35:34.437108+00
d7e5f722-dbf7-42cf-a1e0-409c07ad4bb5	f258f9ba-41a0-4aa9-8d2f-74652b159932	2	available	\N	\N	\N
9c96d341-a060-4960-95c7-e2939f17534d	f258f9ba-41a0-4aa9-8d2f-74652b159932	3	available	\N	\N	\N
87ae2834-0adf-47d5-9124-ded1f9d15567	f258f9ba-41a0-4aa9-8d2f-74652b159932	1	pending	test_buyer	2026-05-31 08:35:34.475786+00	\N
b5fe3e70-6918-4884-94fc-b3b892cf69df	e829e15b-906a-4565-a701-fadc88a0269f	3	loser	buyer_a	2026-05-31 12:38:54.235045+00	2026-05-31 12:38:54.250016+00
3bebe5cf-bda1-4ee8-9c75-9e5f7f851752	e829e15b-906a-4565-a701-fadc88a0269f	5	winner	buyer_b	2026-05-31 12:38:54.238906+00	2026-05-31 12:38:54.256744+00
3a0a5d07-4b91-4192-8a78-3fee2910aa3b	e9b10c7a-155a-426c-b44a-319cb51784af	2	available	\N	\N	\N
d551bdc7-37ea-4268-b01a-72e365cc1912	e9b10c7a-155a-426c-b44a-319cb51784af	3	available	\N	\N	\N
e20c9523-1fdd-433b-8f7f-679d1a7b259b	43e44a34-ee1b-4341-a027-5e889f34fcc0	3	paid	buyer_a	2026-05-31 09:55:13.660423+00	2026-05-31 09:55:13.682639+00
44eff7c4-5303-43d9-8e9b-7bb27cfad505	43e44a34-ee1b-4341-a027-5e889f34fcc0	1	paid	buyer_a	2026-05-31 09:55:13.656992+00	2026-05-31 09:55:13.677148+00
d1a636e0-9345-4a88-9e44-2ede00c65eef	43e44a34-ee1b-4341-a027-5e889f34fcc0	2	paid	buyer_a	2026-05-31 09:55:13.659186+00	2026-05-31 09:55:13.679203+00
bd52da82-5494-4096-9eba-5d33140d2442	43e44a34-ee1b-4341-a027-5e889f34fcc0	4	paid	buyer_b	2026-05-31 09:55:13.671424+00	2026-05-31 09:55:13.686291+00
88452939-7a32-4364-ba23-b23cf31d0200	43e44a34-ee1b-4341-a027-5e889f34fcc0	5	paid	buyer_b	2026-05-31 09:55:13.672289+00	2026-05-31 09:55:13.691013+00
3690b686-c63d-4807-8906-60c094cfb68a	b760eecb-035c-479f-bfcd-61adf24376bf	1	loser	buyer_a	2026-05-31 08:35:34.48437+00	2026-05-31 08:35:34.490897+00
0603fd10-619f-4730-9736-752c47844b33	b760eecb-035c-479f-bfcd-61adf24376bf	2	loser	buyer_a	2026-05-31 08:35:34.484827+00	2026-05-31 08:35:34.492695+00
13bc31af-a87e-4abb-9fad-0d823e366595	b760eecb-035c-479f-bfcd-61adf24376bf	4	loser	buyer_b	2026-05-31 08:35:34.488143+00	2026-05-31 08:35:34.49702+00
bac24392-53b4-4574-bb32-4d4f0394a8b4	f149228e-3780-4f2f-aab2-1775a1fecdcf	2	available	\N	\N	\N
0faeaa8f-cb8b-4812-bf83-c428c61df8f1	b760eecb-035c-479f-bfcd-61adf24376bf	3	loser	buyer_a	2026-05-31 08:35:34.485245+00	2026-05-31 08:35:34.495156+00
c289c1e6-4533-4010-8b0b-a1788b6e1d87	b760eecb-035c-479f-bfcd-61adf24376bf	5	winner	buyer_b	2026-05-31 08:35:34.48861+00	2026-05-31 08:35:34.499995+00
b9d92b4e-677e-4ac8-82b0-6d4c17db712e	9cc5a5dc-a470-469e-84a9-67e1bb3accce	2	available	\N	\N	\N
e4429cb3-2a30-424c-92a9-710784c4c4df	9cc5a5dc-a470-469e-84a9-67e1bb3accce	3	available	\N	\N	\N
b50dfbf6-88e7-41e5-b0f8-1ae296538b79	9cc5a5dc-a470-469e-84a9-67e1bb3accce	1	pending	test_buyer	2026-05-31 08:35:34.535699+00	\N
95eb5090-7d7a-417d-9af9-a49125057ba1	f149228e-3780-4f2f-aab2-1775a1fecdcf	3	available	\N	\N	\N
bd4550b7-739a-42f7-b01b-169ebda651dd	f149228e-3780-4f2f-aab2-1775a1fecdcf	1	pending	test_buyer	2026-05-31 09:55:13.849435+00	\N
1e766cac-a121-437a-acc3-6bb1db98cd86	e9b10c7a-155a-426c-b44a-319cb51784af	1	pending	test_buyer	2026-05-31 12:38:54.309007+00	\N
6f4fb6a7-e84e-481f-9d2c-1afaf1815995	1c085be0-7d56-46da-b681-bf2973ca64ec	3	winner	buyer_a	2026-05-31 08:35:34.545756+00	2026-05-31 08:35:34.556395+00
f916fd37-bb35-40e6-a755-a2d8abfe9415	1c085be0-7d56-46da-b681-bf2973ca64ec	1	loser	buyer_a	2026-05-31 08:35:34.544833+00	2026-05-31 08:35:34.551669+00
e126ae55-c263-427b-9ae6-dfe811d3ac93	1c085be0-7d56-46da-b681-bf2973ca64ec	2	loser	buyer_a	2026-05-31 08:35:34.54532+00	2026-05-31 08:35:34.553369+00
7ecef27c-ba42-4d8c-80ce-147692ddc0d1	1c085be0-7d56-46da-b681-bf2973ca64ec	4	loser	buyer_b	2026-05-31 08:35:34.54857+00	2026-05-31 08:35:34.557883+00
dbeac208-f5aa-43fa-bbe1-4717b7603086	1c085be0-7d56-46da-b681-bf2973ca64ec	5	loser	buyer_b	2026-05-31 08:35:34.549112+00	2026-05-31 08:35:34.559842+00
b1a8eb52-3a3f-4d3b-b898-ddb40e8d20de	01cacd0e-cf0e-4fda-b6f3-70bf44f0c316	3	paid	buyer_a	2026-05-31 12:38:54.13941+00	2026-05-31 12:38:54.154379+00
035d2c04-35ef-4fe4-b994-b44f60152348	5fdaa77b-7aea-47ef-9739-64c67c4689c7	3	winner	buyer_a	2026-05-31 09:55:13.911022+00	2026-05-31 09:55:13.91958+00
d7e6ec9c-84b6-47ff-9bab-c2c34e34dae4	5fdaa77b-7aea-47ef-9739-64c67c4689c7	1	loser	buyer_a	2026-05-31 09:55:13.910128+00	2026-05-31 09:55:13.915753+00
d9e3077d-d23b-43ad-a744-8c7f9918c11d	5fdaa77b-7aea-47ef-9739-64c67c4689c7	2	loser	buyer_a	2026-05-31 09:55:13.910553+00	2026-05-31 09:55:13.918225+00
9d8e0f89-4616-4baf-9079-bb404e239a29	5fdaa77b-7aea-47ef-9739-64c67c4689c7	4	loser	buyer_b	2026-05-31 09:55:13.913186+00	2026-05-31 09:55:13.920767+00
1d92e044-d387-48c2-8e85-69d06eb11bf6	5fdaa77b-7aea-47ef-9739-64c67c4689c7	5	loser	buyer_b	2026-05-31 09:55:13.913604+00	2026-05-31 09:55:13.921895+00
e7c0fb6d-2886-4e4e-9e1a-9fc71c523983	01cacd0e-cf0e-4fda-b6f3-70bf44f0c316	2	paid	buyer_a	2026-05-31 12:38:54.138815+00	2026-05-31 12:38:54.151814+00
fe34daf4-6233-4667-b892-e818beb8c957	1ad9926e-f4b2-4371-8700-4eac8db8c58e	1	loser	buyer_a	2026-05-31 09:55:13.856684+00	2026-05-31 09:55:13.862818+00
8b5133af-5b63-4a9e-a834-006f6bca4c4e	1ad9926e-f4b2-4371-8700-4eac8db8c58e	2	loser	buyer_a	2026-05-31 09:55:13.85722+00	2026-05-31 09:55:13.864911+00
2fa1ea65-a266-4bf8-9786-0a2472d06b0c	1ad9926e-f4b2-4371-8700-4eac8db8c58e	4	loser	buyer_b	2026-05-31 09:55:13.860191+00	2026-05-31 09:55:13.874361+00
e5c09743-7160-4274-85ee-de43323e2adb	01cacd0e-cf0e-4fda-b6f3-70bf44f0c316	4	paid	buyer_b	2026-05-31 12:38:54.144048+00	2026-05-31 12:38:54.15759+00
cc10376a-a0c3-46fb-aa30-8211f79e7e6c	1ad9926e-f4b2-4371-8700-4eac8db8c58e	3	loser	buyer_a	2026-05-31 09:55:13.85778+00	2026-05-31 09:55:13.870313+00
0045581a-76cd-48fe-91cb-9cc773fd816d	01cacd0e-cf0e-4fda-b6f3-70bf44f0c316	5	paid	buyer_b	2026-05-31 12:38:54.144799+00	2026-05-31 12:38:54.161317+00
4131d75b-d234-427b-9aaf-a14c00cbc786	e829e15b-906a-4565-a701-fadc88a0269f	1	loser	buyer_a	2026-05-31 12:38:54.233355+00	2026-05-31 12:38:54.24366+00
95e116d2-27c4-4a4a-9e86-3baa888b3d97	e829e15b-906a-4565-a701-fadc88a0269f	2	loser	buyer_a	2026-05-31 12:38:54.233852+00	2026-05-31 12:38:54.246909+00
75858ffc-5763-4c89-bbdc-655bbafe35d9	e829e15b-906a-4565-a701-fadc88a0269f	4	loser	buyer_b	2026-05-31 12:38:54.238491+00	2026-05-31 12:38:54.253457+00
e60a8425-e0ae-4663-a7e2-a35f71f15a14	01cacd0e-cf0e-4fda-b6f3-70bf44f0c316	1	paid	buyer_a	2026-05-31 12:38:54.138035+00	2026-05-31 12:38:54.149305+00
e8f16af9-d76a-4b25-8f52-422b94b942d9	7ef62753-923b-4953-97c9-1d6f868d5b8c	2	available	\N	\N	\N
00a6ec98-d882-47a1-ae35-5ecfa64c586d	7ef62753-923b-4953-97c9-1d6f868d5b8c	3	available	\N	\N	\N
dc1e8968-f919-4726-b65d-27d5e337ca01	7ef62753-923b-4953-97c9-1d6f868d5b8c	1	pending	test_buyer	2026-05-31 12:38:54.221143+00	\N
1b44e517-fe7a-4709-bcac-228bbede1e94	04286455-e723-4d19-b3c4-7b52114fa750	3	winner	buyer_a	2026-05-31 12:38:54.321471+00	2026-05-31 12:38:54.338601+00
bab646d0-4d7c-4a12-a1d7-c3bae0669f8d	04286455-e723-4d19-b3c4-7b52114fa750	1	loser	buyer_a	2026-05-31 12:38:54.319868+00	2026-05-31 12:38:54.331276+00
aee71123-0508-4d5e-ba54-4136be6f63bd	04286455-e723-4d19-b3c4-7b52114fa750	5	loser	buyer_b	2026-05-31 12:38:54.328189+00	2026-05-31 12:38:54.345816+00
67d17674-4ecf-423d-a300-6a4785e6ca35	70bfdcd5-1290-4895-8439-d8da599d2559	3	paid	buyer_a	2026-05-31 12:57:24.104979+00	2026-05-31 12:57:24.116175+00
ee701d4e-3b28-40b4-bc92-6229c660ceab	04286455-e723-4d19-b3c4-7b52114fa750	2	loser	buyer_a	2026-05-31 12:38:54.320695+00	2026-05-31 12:38:54.335111+00
6f6d482a-6cde-448f-a828-2d5d1dc60684	04286455-e723-4d19-b3c4-7b52114fa750	4	loser	buyer_b	2026-05-31 12:38:54.327721+00	2026-05-31 12:38:54.342498+00
07546ad1-df96-4377-9890-7faeb57a8ef8	70bfdcd5-1290-4895-8439-d8da599d2559	2	paid	buyer_a	2026-05-31 12:57:24.103152+00	2026-05-31 12:57:24.114182+00
e8e6c154-5712-467c-b969-affd86f428bb	70bfdcd5-1290-4895-8439-d8da599d2559	4	paid	buyer_b	2026-05-31 12:57:24.107926+00	2026-05-31 12:57:24.11804+00
9e4e6ace-664d-45f2-aa18-2c94d12f02f9	70bfdcd5-1290-4895-8439-d8da599d2559	5	paid	buyer_b	2026-05-31 12:57:24.108395+00	2026-05-31 12:57:24.120616+00
a16422ee-55e6-494c-8850-28232053d7d0	70bfdcd5-1290-4895-8439-d8da599d2559	1	paid	buyer_a	2026-05-31 12:57:24.102336+00	2026-05-31 12:57:24.112304+00
2589c010-98a6-454e-ab57-c8e37083effe	d0f59974-bf19-4d6c-bce4-d3d20bb88307	2	available	\N	\N	\N
9d0b1e85-e662-42ee-96dc-08e8dbe0cfa5	d0f59974-bf19-4d6c-bce4-d3d20bb88307	3	available	\N	\N	\N
8622f456-1a57-4c4a-bf56-86576a18eec1	d0f59974-bf19-4d6c-bce4-d3d20bb88307	1	pending	test_buyer	2026-05-31 12:57:24.172543+00	\N
16081ad8-da92-4fa3-8bbe-9e0001a073df	9c8c96ba-da01-4a5e-8111-67559da47f15	4	loser	buyer_b	2026-05-31 12:57:24.187873+00	2026-05-31 12:57:24.197088+00
dd63e8f3-4a1f-47ea-af0f-6d75a4946c23	63abf727-159b-4a26-aa35-f6a49e70e5da	3	loser	buyer_a	2026-05-31 15:55:27.115656+00	2026-05-31 15:55:27.13216+00
bf79e1b5-aa03-46b1-85a2-eef765cdbb0d	63abf727-159b-4a26-aa35-f6a49e70e5da	5	winner	buyer_b	2026-05-31 15:55:27.121879+00	2026-05-31 15:55:27.138116+00
f454be24-3d3c-4d8c-950f-7972cb142a96	9c8c96ba-da01-4a5e-8111-67559da47f15	1	loser	buyer_a	2026-05-31 12:57:24.182737+00	2026-05-31 12:57:24.190748+00
3d8aa440-6c3a-4f8a-97e5-68abb22ada8c	9c8c96ba-da01-4a5e-8111-67559da47f15	2	loser	buyer_a	2026-05-31 12:57:24.18412+00	2026-05-31 12:57:24.192711+00
8e1a9389-2b16-401b-b5b2-35d432e2379c	9c8c96ba-da01-4a5e-8111-67559da47f15	3	loser	buyer_a	2026-05-31 12:57:24.185158+00	2026-05-31 12:57:24.194564+00
1306bd82-9be1-4ddb-8483-e8e4d9f9af96	9c8c96ba-da01-4a5e-8111-67559da47f15	5	winner	buyer_b	2026-05-31 12:57:24.188503+00	2026-05-31 12:57:24.200191+00
f92c90da-9bae-48b4-9c54-68986c53eeae	6d659823-d579-4a38-a649-12bb02c3e402	2	available	\N	\N	\N
f65e7368-f1fe-4319-a2d5-e5e04a534da2	6d659823-d579-4a38-a649-12bb02c3e402	3	available	\N	\N	\N
6d2b2b82-77fa-433d-b345-1e1636d5df5e	6d659823-d579-4a38-a649-12bb02c3e402	1	pending	test_buyer	2026-05-31 12:57:24.23585+00	\N
5cff7792-79df-4404-a372-e2eab6ee6a35	e75295e4-4972-48d9-a2b6-8fcf91af134a	2	available	\N	\N	\N
af6e6733-4d76-404b-979b-f8341f15e851	e75295e4-4972-48d9-a2b6-8fcf91af134a	3	available	\N	\N	\N
dc6cbc7d-b5bc-4d4f-be02-255dcc3a5f58	e75295e4-4972-48d9-a2b6-8fcf91af134a	1	pending	test_buyer	2026-05-31 15:55:27.190369+00	\N
6151f7d1-f58d-4562-a9e4-dca6b83586e8	795d39b1-fed0-4b15-87ef-e6cde159a1ba	1	pending	test_buyer	2026-05-31 16:01:03.268079+00	\N
92565c0d-b4b2-47fb-a96d-de25ca4edc8d	bd600a4a-416d-4515-87c4-2beb9ad65844	3	winner	buyer_a	2026-05-31 12:57:24.243517+00	2026-05-31 12:57:24.25194+00
af6b6a5f-67a7-476b-bf8f-3ae323f2680c	bd600a4a-416d-4515-87c4-2beb9ad65844	1	loser	buyer_a	2026-05-31 12:57:24.243071+00	2026-05-31 12:57:24.248954+00
27934de6-fe2b-46da-9648-1f1720ee75b6	bd600a4a-416d-4515-87c4-2beb9ad65844	2	loser	buyer_a	2026-05-31 12:57:24.243275+00	2026-05-31 12:57:24.250058+00
d802ea71-a0a5-4dda-849c-667e4f6dc340	bd600a4a-416d-4515-87c4-2beb9ad65844	4	loser	buyer_b	2026-05-31 12:57:24.246998+00	2026-05-31 12:57:24.253302+00
af9c19bb-00fb-416a-8116-329c61d4a77a	bd600a4a-416d-4515-87c4-2beb9ad65844	5	loser	buyer_b	2026-05-31 12:57:24.247194+00	2026-05-31 12:57:24.255044+00
14209db1-983d-42c3-b73e-6c4d7201db1a	5221719c-43f9-45ea-b7eb-e421f8aea70c	1	pending	test_buyer	2026-06-04 06:35:29.658183+00	\N
2f6bbf13-8028-4fc4-87a9-ef8a9795e6c1	f1e823df-265b-46ca-9ca8-6d8977e332b4	1	loser	buyer_a	2026-06-04 06:35:29.617669+00	2026-06-04 06:35:29.623114+00
f18f53fc-2c87-4145-861d-363ebe3b9826	f1e823df-265b-46ca-9ca8-6d8977e332b4	2	loser	buyer_a	2026-06-04 06:35:29.617995+00	2026-06-04 06:35:29.624539+00
3f4870cf-528f-4339-89f9-37e7b005ba60	f1e823df-265b-46ca-9ca8-6d8977e332b4	4	loser	buyer_b	2026-06-04 06:35:29.620546+00	2026-06-04 06:35:29.627247+00
819da05c-41da-4972-af0a-908743accc30	cfb15ed5-49f3-412d-a947-dc5ee49c63d2	3	winner	buyer_a	2026-05-31 15:55:27.201673+00	2026-05-31 15:55:27.218452+00
1744ab8a-42c0-4bba-ba73-d01013c66ff1	cfb15ed5-49f3-412d-a947-dc5ee49c63d2	1	loser	buyer_a	2026-05-31 15:55:27.200494+00	2026-05-31 15:55:27.213425+00
107bc12c-2caf-4979-878e-6fc7636e29c7	cfb15ed5-49f3-412d-a947-dc5ee49c63d2	2	loser	buyer_a	2026-05-31 15:55:27.201094+00	2026-05-31 15:55:27.215779+00
1ccecc0c-2c22-4f25-89f2-33228cb4960a	cfb15ed5-49f3-412d-a947-dc5ee49c63d2	4	loser	buyer_b	2026-05-31 15:55:27.207971+00	2026-05-31 15:55:27.220517+00
f0ff2539-5a90-4a28-a9c7-2da76d8d1ea0	cfb15ed5-49f3-412d-a947-dc5ee49c63d2	5	loser	buyer_b	2026-05-31 15:55:27.208803+00	2026-05-31 15:55:27.222676+00
f4f9a92d-fcf0-49ae-8767-0dbc9ced2bc0	8a93df0d-9d96-4c61-8f7c-c8cccbdf18a0	3	paid	buyer_a	2026-05-31 15:55:26.992179+00	2026-05-31 15:55:27.014872+00
a46d01e4-7d9c-46f6-ac11-290d5a6859ff	8a93df0d-9d96-4c61-8f7c-c8cccbdf18a0	1	paid	buyer_a	2026-05-31 15:55:26.990465+00	2026-05-31 15:55:27.007968+00
1c254ff6-a232-4464-92e3-47a5e86e2e8f	8a93df0d-9d96-4c61-8f7c-c8cccbdf18a0	2	paid	buyer_a	2026-05-31 15:55:26.9914+00	2026-05-31 15:55:27.010766+00
108cbf31-7575-4824-9345-f88ee427db08	8a93df0d-9d96-4c61-8f7c-c8cccbdf18a0	4	paid	buyer_b	2026-05-31 15:55:26.99965+00	2026-05-31 15:55:27.018819+00
c0c6338d-9dfe-4136-8709-7a3e03cd30b9	8a93df0d-9d96-4c61-8f7c-c8cccbdf18a0	5	paid	buyer_b	2026-05-31 15:55:27.000843+00	2026-05-31 15:55:27.022227+00
78aa692b-113b-47b3-ad9a-1709cc586118	1bb09252-93c6-4638-a8e6-bb5141d3b004	2	available	\N	\N	\N
0da0ab30-38af-4ccb-a1dd-11892d570fe0	1bb09252-93c6-4638-a8e6-bb5141d3b004	3	available	\N	\N	\N
0e7e698c-95aa-47f4-8f77-35a1717466b1	1bb09252-93c6-4638-a8e6-bb5141d3b004	1	pending	test_buyer	2026-05-31 15:55:27.103692+00	\N
0f092d37-ee03-4fec-bd7e-6fc5c640681d	a75f0133-008a-4ff0-a70e-270375cea185	3	winner	buyer_a	2026-05-31 16:01:03.393452+00	2026-05-31 16:01:03.411106+00
587f04dc-8d23-4684-8c23-66a7defec3c8	a75f0133-008a-4ff0-a70e-270375cea185	2	loser	buyer_a	2026-05-31 16:01:03.392463+00	2026-05-31 16:01:03.408354+00
53d59b1e-44d7-464e-b443-5cef0360ce60	a75f0133-008a-4ff0-a70e-270375cea185	4	loser	buyer_b	2026-05-31 16:01:03.400039+00	2026-05-31 16:01:03.413343+00
3d5fa65f-c74e-42b5-aeca-06a238863bf2	a75f0133-008a-4ff0-a70e-270375cea185	5	loser	buyer_b	2026-05-31 16:01:03.400978+00	2026-05-31 16:01:03.416329+00
aac0c861-5450-4ff7-9eae-bc5b71b7c461	a75f0133-008a-4ff0-a70e-270375cea185	1	loser	buyer_a	2026-05-31 16:01:03.391596+00	2026-05-31 16:01:03.405086+00
d7bd43c7-98e9-4d02-bb6d-1d6319ab5af1	6237a959-8703-4691-a06a-fa4a2509246e	1	loser	buyer_a	2026-05-31 16:01:03.285778+00	2026-05-31 16:01:03.298061+00
4bcce149-c4ee-42f2-b4a2-90a54a4c5d4f	63abf727-159b-4a26-aa35-f6a49e70e5da	1	loser	buyer_a	2026-05-31 15:55:27.114291+00	2026-05-31 15:55:27.126622+00
30703fc3-6373-4807-9535-6d25100c46f4	63abf727-159b-4a26-aa35-f6a49e70e5da	2	loser	buyer_a	2026-05-31 15:55:27.115173+00	2026-05-31 15:55:27.129474+00
099bc511-18ba-4847-8c3e-66fdb11c1618	63abf727-159b-4a26-aa35-f6a49e70e5da	4	loser	buyer_b	2026-05-31 15:55:27.120995+00	2026-05-31 15:55:27.135354+00
61f49511-e41a-43f6-8417-80586268e8da	6237a959-8703-4691-a06a-fa4a2509246e	2	loser	buyer_a	2026-05-31 16:01:03.286638+00	2026-05-31 16:01:03.301048+00
8b459e78-c4b6-42fd-b9f4-e2b5daaf74b6	6237a959-8703-4691-a06a-fa4a2509246e	4	loser	buyer_b	2026-05-31 16:01:03.293573+00	2026-05-31 16:01:03.309388+00
f19d630d-a316-4ef8-aad6-a3daf4386d29	6237a959-8703-4691-a06a-fa4a2509246e	3	loser	buyer_a	2026-05-31 16:01:03.287826+00	2026-05-31 16:01:03.306049+00
11e8bb18-bd1a-4abe-b1a2-a5467c6c8a6e	6237a959-8703-4691-a06a-fa4a2509246e	5	winner	buyer_b	2026-05-31 16:01:03.294098+00	2026-05-31 16:01:03.312754+00
d069eef7-326c-4cf1-b925-a6d4d2552e5b	7d9fdd9a-b84c-4e95-a568-51f1439d92d6	2	available	\N	\N	\N
cac3bc3b-fe1b-4fd4-ab98-4395506c2ae2	7d9fdd9a-b84c-4e95-a568-51f1439d92d6	3	available	\N	\N	\N
258c807d-1bed-4022-8a7e-04a6e474e17a	7d9fdd9a-b84c-4e95-a568-51f1439d92d6	1	pending	test_buyer	2026-05-31 16:01:03.376192+00	\N
111e6d21-0468-42b6-876f-b2c411b36038	90de122b-7663-4d06-8d3b-6551edf71998	3	paid	buyer_a	2026-05-31 16:01:03.155928+00	2026-05-31 16:01:03.177076+00
386d297d-8278-4206-b8b1-855a020b735b	90de122b-7663-4d06-8d3b-6551edf71998	1	paid	buyer_a	2026-05-31 16:01:03.152748+00	2026-05-31 16:01:03.170301+00
40bd492a-a93a-49e6-873e-95a1c543b312	90de122b-7663-4d06-8d3b-6551edf71998	2	paid	buyer_a	2026-05-31 16:01:03.15452+00	2026-05-31 16:01:03.174071+00
4d85ff63-6919-435a-8515-3b3ca5324b9a	90de122b-7663-4d06-8d3b-6551edf71998	4	paid	buyer_b	2026-05-31 16:01:03.162709+00	2026-05-31 16:01:03.180487+00
2bdd4c0c-d337-4841-8b08-9b0cc8269e21	90de122b-7663-4d06-8d3b-6551edf71998	5	paid	buyer_b	2026-05-31 16:01:03.163739+00	2026-05-31 16:01:03.185822+00
f08784d4-e95a-4e05-8ff7-37fb3731ee83	795d39b1-fed0-4b15-87ef-e6cde159a1ba	2	available	\N	\N	\N
18f68d11-a0dd-4c9b-be40-2e43e544c64f	795d39b1-fed0-4b15-87ef-e6cde159a1ba	3	available	\N	\N	\N
5224e9c3-bee3-43ad-aa60-5b2057a83fe5	6c01d7f8-3580-47f4-af2d-afd96d94e3fa	3	paid	buyer_a	2026-06-04 06:35:29.570056+00	2026-06-04 06:35:29.578922+00
2357ed08-ab8f-476d-9eb5-654bad551f40	6c01d7f8-3580-47f4-af2d-afd96d94e3fa	5	paid	buyer_b	2026-06-04 06:35:29.572942+00	2026-06-04 06:35:29.582045+00
75f8ae34-97ed-4d3a-9a38-d138db318afa	6c01d7f8-3580-47f4-af2d-afd96d94e3fa	1	paid	buyer_a	2026-06-04 06:35:29.569001+00	2026-06-04 06:35:29.575737+00
63156e78-0569-4a83-9e69-9eef4b5238a9	6c01d7f8-3580-47f4-af2d-afd96d94e3fa	2	paid	buyer_a	2026-06-04 06:35:29.569624+00	2026-06-04 06:35:29.57737+00
8ba7c028-4d94-41a4-885a-d1f2cff2b265	6c01d7f8-3580-47f4-af2d-afd96d94e3fa	4	paid	buyer_b	2026-06-04 06:35:29.572459+00	2026-06-04 06:35:29.580344+00
16be0da0-309b-4a2e-a762-684ced8beab6	2e190df7-b395-42f0-9865-2e2a34b0421d	2	available	\N	\N	\N
d22c8870-4d3b-456a-9c1c-10311591910b	f1e823df-265b-46ca-9ca8-6d8977e332b4	3	loser	buyer_a	2026-06-04 06:35:29.61829+00	2026-06-04 06:35:29.625985+00
7c67d03c-e039-4107-a939-5df61f99b18d	2e190df7-b395-42f0-9865-2e2a34b0421d	3	available	\N	\N	\N
273d498a-bb15-4ffd-aabf-2517984b87f9	2e190df7-b395-42f0-9865-2e2a34b0421d	1	pending	test_buyer	2026-06-04 06:35:29.611994+00	\N
359cedd6-4692-43a3-8e99-cc25799ac189	f1e823df-265b-46ca-9ca8-6d8977e332b4	5	winner	buyer_b	2026-06-04 06:35:29.62091+00	2026-06-04 06:35:29.628508+00
bc6080d0-5e46-4d47-8e53-d47d6b6076cb	5221719c-43f9-45ea-b7eb-e421f8aea70c	2	available	\N	\N	\N
df568abf-5644-473f-89f0-95248a1a43e8	5221719c-43f9-45ea-b7eb-e421f8aea70c	3	available	\N	\N	\N
6e7b4000-72b3-495a-be1d-50a3637d9f67	2f308ab1-2528-454f-99db-758f8e02f3f3	3	winner	buyer_a	2026-06-04 06:35:29.665313+00	2026-06-04 06:35:29.672565+00
69e35abf-9389-46b0-8dc1-b4ab621b5b40	2f308ab1-2528-454f-99db-758f8e02f3f3	2	loser	buyer_a	2026-06-04 06:35:29.664891+00	2026-06-04 06:35:29.671148+00
c3d999a4-8688-4ff7-b496-cbcfb55b8d98	2f308ab1-2528-454f-99db-758f8e02f3f3	4	loser	buyer_b	2026-06-04 06:35:29.667644+00	2026-06-04 06:35:29.673959+00
a803bd2b-c4c7-4a27-9f30-5248074a2da5	2f308ab1-2528-454f-99db-758f8e02f3f3	5	loser	buyer_b	2026-06-04 06:35:29.667927+00	2026-06-04 06:35:29.675338+00
b9c14b4b-e8a0-4e30-ab21-0dc6e07db279	2f308ab1-2528-454f-99db-758f8e02f3f3	1	loser	buyer_a	2026-06-04 06:35:29.664515+00	2026-06-04 06:35:29.669878+00
b79a6372-b398-4fea-a7b9-6e7b0a66e29a	6c2b3769-756c-4a9e-93f0-ef41a79953ac	3	paid	buyer_a	2026-06-04 07:36:53.724333+00	2026-06-04 07:36:53.738043+00
8ab78dfe-b75d-4b04-a4ba-30e3045cc651	6c2b3769-756c-4a9e-93f0-ef41a79953ac	2	paid	buyer_a	2026-06-04 07:36:53.723758+00	2026-06-04 07:36:53.735907+00
4169dabb-5a4b-4035-95e5-4193a3b74f87	6c2b3769-756c-4a9e-93f0-ef41a79953ac	4	paid	buyer_b	2026-06-04 07:36:53.728467+00	2026-06-04 07:36:53.740744+00
7f16691c-16be-47bc-b2ab-1f74ad8738b3	6c2b3769-756c-4a9e-93f0-ef41a79953ac	5	paid	buyer_b	2026-06-04 07:36:53.729111+00	2026-06-04 07:36:53.743458+00
3b55493a-7941-4603-8d67-f1bbb5202928	6c2b3769-756c-4a9e-93f0-ef41a79953ac	1	paid	buyer_a	2026-06-04 07:36:53.722978+00	2026-06-04 07:36:53.733614+00
d87a2fe3-e66a-4174-9a4a-f05a51c14294	771d423f-7e7f-4b92-9040-4f07e3419368	2	available	\N	\N	\N
a2b5a1cb-88c9-42a1-a223-dbd7d06f0b9a	771d423f-7e7f-4b92-9040-4f07e3419368	3	available	\N	\N	\N
af3fcf5c-c55b-4821-a352-d4069c85809b	771d423f-7e7f-4b92-9040-4f07e3419368	1	pending	test_buyer	2026-06-04 07:36:53.800186+00	\N
bb45bffd-89eb-464e-af6e-6fb70396513f	fc30b295-0f06-4b2a-9da8-ef1cfb4cc5cc	3	paid	buyer_a	2026-06-04 07:37:38.724983+00	2026-06-04 07:37:38.745652+00
bd99722e-9a0e-40e5-b099-e3025eb623ca	fc30b295-0f06-4b2a-9da8-ef1cfb4cc5cc	4	paid	buyer_b	2026-06-04 07:37:38.731928+00	2026-06-04 07:37:38.74771+00
52bc39f3-3b92-41aa-9264-8405d17a4f17	fc30b295-0f06-4b2a-9da8-ef1cfb4cc5cc	5	paid	buyer_b	2026-06-04 07:37:38.73286+00	2026-06-04 07:37:38.749481+00
d0dfec5a-6a25-4e5a-a112-94cc6d068b82	fc30b295-0f06-4b2a-9da8-ef1cfb4cc5cc	1	paid	buyer_a	2026-06-04 07:37:38.723459+00	2026-06-04 07:37:38.739106+00
2ab7d6e6-e847-40fb-829d-9d49d498593b	fc30b295-0f06-4b2a-9da8-ef1cfb4cc5cc	2	paid	buyer_a	2026-06-04 07:37:38.724406+00	2026-06-04 07:37:38.742004+00
42a91db3-8028-4e66-a01f-1ddb8e506eca	abe882bc-df15-4881-9b02-7e046d738a6a	2	available	\N	\N	\N
ab1aec15-bc2e-4a43-8e69-d59242494893	abe882bc-df15-4881-9b02-7e046d738a6a	3	available	\N	\N	\N
3bd60131-ae33-42aa-b77e-6f6950fcb16d	abe882bc-df15-4881-9b02-7e046d738a6a	1	pending	test_buyer	2026-06-04 07:37:38.796346+00	\N
25ae49ff-3571-49e4-9b90-4d3ac7e795d3	80b4aa08-2c80-4a4c-ab7a-6856df44077c	5	winner	buyer_b	2026-06-04 07:36:53.815567+00	2026-06-04 07:36:53.82835+00
04e59f6c-6dcc-43c8-932b-ff965d2bf6e2	80b4aa08-2c80-4a4c-ab7a-6856df44077c	3	loser	buyer_a	2026-06-04 07:36:53.811031+00	2026-06-04 07:36:53.824261+00
9bcec8f2-94c2-4369-a886-3455440fba00	80b4aa08-2c80-4a4c-ab7a-6856df44077c	1	loser	buyer_a	2026-06-04 07:36:53.809867+00	2026-06-04 07:36:53.819362+00
4877623c-36f0-4606-99de-f0fbe2f0b298	80b4aa08-2c80-4a4c-ab7a-6856df44077c	2	loser	buyer_a	2026-06-04 07:36:53.810411+00	2026-06-04 07:36:53.822138+00
dac2337a-c8e9-43bb-bec6-2c1e1c925e04	80b4aa08-2c80-4a4c-ab7a-6856df44077c	4	loser	buyer_b	2026-06-04 07:36:53.814897+00	2026-06-04 07:36:53.826292+00
f8e23a02-f826-4016-ac30-473854d33e89	11e1a13d-4d7d-4173-a559-0c652258a6c9	2	available	\N	\N	\N
50144216-7b5b-4b7f-b513-314f2ce806cf	11e1a13d-4d7d-4173-a559-0c652258a6c9	3	available	\N	\N	\N
4b9b8aad-f271-4388-9cc6-cbbc0b817716	11e1a13d-4d7d-4173-a559-0c652258a6c9	1	pending	test_buyer	2026-06-04 07:36:53.872295+00	\N
26e20f0c-dc4d-40cb-b845-4fb445fda9ea	24651645-3d0d-4d1c-91b1-d2fc4e39733d	3	winner	buyer_a	2026-06-04 07:37:38.877405+00	2026-06-04 07:37:38.886742+00
cafa0e8f-3fbc-4eb1-93df-661eaab15363	24651645-3d0d-4d1c-91b1-d2fc4e39733d	1	loser	buyer_a	2026-06-04 07:37:38.876435+00	2026-06-04 07:37:38.883486+00
584998da-186d-4c73-8710-b48a1d7f4266	24651645-3d0d-4d1c-91b1-d2fc4e39733d	2	loser	buyer_a	2026-06-04 07:37:38.876939+00	2026-06-04 07:37:38.885116+00
320d148b-28ec-45a2-a24e-9f6941ba7acc	24651645-3d0d-4d1c-91b1-d2fc4e39733d	4	loser	buyer_b	2026-06-04 07:37:38.880548+00	2026-06-04 07:37:38.889087+00
2c04eb03-24ce-4ec7-b2af-4bba378ab843	24651645-3d0d-4d1c-91b1-d2fc4e39733d	5	loser	buyer_b	2026-06-04 07:37:38.881025+00	2026-06-04 07:37:38.890874+00
4257d510-e525-4e1b-92c1-dab1bf5f36a3	7f74e30d-cbf8-473a-a8f1-f223a7dc7698	3	winner	buyer_a	2026-06-04 07:36:53.884062+00	2026-06-04 07:36:53.897545+00
1d5d47f1-926e-48cc-b49b-6e4fbc255457	7f74e30d-cbf8-473a-a8f1-f223a7dc7698	1	loser	buyer_a	2026-06-04 07:36:53.882633+00	2026-06-04 07:36:53.892317+00
34f1e983-de22-4d6f-ac5f-1be10373df78	7f74e30d-cbf8-473a-a8f1-f223a7dc7698	2	loser	buyer_a	2026-06-04 07:36:53.883369+00	2026-06-04 07:36:53.894712+00
3dd5779a-257a-4ff0-89c4-3be3c31800f8	7f74e30d-cbf8-473a-a8f1-f223a7dc7698	4	loser	buyer_b	2026-06-04 07:36:53.887958+00	2026-06-04 07:36:53.899947+00
8edd4407-d530-4304-87cc-629d2feda1d1	7f74e30d-cbf8-473a-a8f1-f223a7dc7698	5	loser	buyer_b	2026-06-04 07:36:53.888485+00	2026-06-04 07:36:53.902158+00
f52f2c13-507e-4071-b014-70286a1f6d2b	207508f1-9de3-4c88-b4c3-d89e2dd65ebb	5	winner	buyer_b	2026-06-04 07:37:38.812733+00	2026-06-04 07:37:38.825721+00
1e916f91-bd0f-4acc-ab7d-30f2e3a35f1a	207508f1-9de3-4c88-b4c3-d89e2dd65ebb	3	loser	buyer_a	2026-06-04 07:37:38.807712+00	2026-06-04 07:37:38.820646+00
72d4d99d-740c-453e-bb7c-2ec8a8935b58	207508f1-9de3-4c88-b4c3-d89e2dd65ebb	1	loser	buyer_a	2026-06-04 07:37:38.806433+00	2026-06-04 07:37:38.816387+00
63a4f436-72e2-4af4-8026-595d85b0452e	207508f1-9de3-4c88-b4c3-d89e2dd65ebb	2	loser	buyer_a	2026-06-04 07:37:38.807104+00	2026-06-04 07:37:38.818467+00
3db78c05-87a3-4845-a6e4-e3d728adc17c	207508f1-9de3-4c88-b4c3-d89e2dd65ebb	4	loser	buyer_b	2026-06-04 07:37:38.811925+00	2026-06-04 07:37:38.823298+00
b118bc15-ee78-4043-80a4-495c7355dc0f	dd8a7229-df0b-462d-a4b9-670501b1d243	2	available	\N	\N	\N
75f6da5a-812e-49e4-8f7d-234c6e824e7e	dd8a7229-df0b-462d-a4b9-670501b1d243	3	available	\N	\N	\N
8dae7531-bf45-4688-92ad-a7db68c19964	dd8a7229-df0b-462d-a4b9-670501b1d243	1	pending	test_buyer	2026-06-04 07:37:38.866973+00	\N
7d8e483e-ab96-490d-9141-d2274ccbc151	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	1	paid	buyer_dani	\N	\N
b8d3b658-4bc3-4a09-981f-3b4d3a3bf2fc	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	2	pending	buyer_dani	\N	\N
d7a32a13-9f2c-4b42-9c96-fd32ff249f80	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	3	paid	buyer_dani	\N	\N
8157bfea-3316-4fea-8cee-a780b65f6a5f	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	4	pending	buyer_boo	\N	\N
67bc6bfb-fed8-4255-8a6a-59e8c5c38a0c	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	5	paid	buyer_boo	\N	\N
32f5dae5-7b0e-40c7-b0a3-b14e71c06f39	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	6	available	\N	\N	\N
f8246a73-f772-4118-8706-898e6b37e96a	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	7	available	\N	\N	\N
df23844a-196a-471e-ba9d-8a4b8f013dda	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	8	available	\N	\N	\N
ec2d873b-212f-4350-aabf-63c86c4e6359	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	9	available	\N	\N	\N
b21eadcf-20bd-494a-aff7-5565515f8c76	c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	10	available	\N	\N	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.system_settings (key, value, updated_at, updated_by) FROM stdin;
password_min_length	8	2026-05-31 05:10:45.410823+00	\N
audit_retention_days	90	2026-05-31 05:10:45.426858+00	\N
login_history_retention_days	90	2026-05-31 05:10:45.426858+00	\N
whois_server	whois.pwhois.org	2026-06-04 07:37:38.62581+00	\N
jwt_expiration_hours	48	2026-06-04 07:33:28.423012+00	0da768f7-45ec-4514-ad28-92dc9dcbfac6
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.users (id, instagram_handle, created_at, updated_at) FROM stdin;
a58002b6-4941-4c83-aa90-5aa4d882075b	test_buyer	2026-05-31 14:55:48.338658+00	2026-05-31 14:55:48.338658+00
58c13f82-e8c9-4c2f-8f7c-41c08e9d4dae	buyer_a	2026-05-31 14:55:48.338658+00	2026-05-31 14:55:48.338658+00
4c94e8af-0a26-4db6-b701-2c4613acba38	buyer_b	2026-05-31 14:55:48.338658+00	2026-05-31 14:55:48.338658+00
baab5dd6-2fdf-4615-92a3-6798ef06fed3		2026-05-31 15:02:37.297433+00	2026-05-31 15:02:37.297433+00
391ec986-0945-41b8-9b00-95266f820a86	buyer_1	2026-06-04 07:37:38.91479+00	2026-06-04 07:37:38.91479+00
0915e5bc-9a40-49ff-b655-2fe189032390	buyer_2	2026-06-04 07:37:38.922405+00	2026-06-04 07:37:38.922405+00
af4a7a37-802c-400d-964e-7a89cf2bc558	buyer_3	2026-06-04 07:37:38.929133+00	2026-06-04 07:37:38.929133+00
c6f17303-7ada-42d6-95f2-b7ac08a1086b	buyer_4	2026-06-04 07:37:38.940094+00	2026-06-04 07:37:38.940094+00
c613fada-0ae1-41d2-a3e7-18f1f560bcd0	buyer_5	2026-06-04 07:37:38.947609+00	2026-06-04 07:37:38.947609+00
8e47b992-212c-4277-9126-adfbf9752cee	buyer_6	2026-06-04 07:37:38.956585+00	2026-06-04 07:37:38.956585+00
915617e4-02b2-4765-b6d0-71a6a9835b8a	buyer_boo	2026-06-04 07:43:59.792966+00	2026-06-04 07:43:59.792966+00
129138fa-4177-40e6-8186-4074e30075e8	buyer_dani	2026-06-04 07:43:59.792966+00	2026-06-04 07:43:59.792966+00
\.


--
-- Data for Name: waffles; Type: TABLE DATA; Schema: public; Owner: syrup
--

COPY public.waffles (id, slug, title, description, image_url, total_spots, spot_price, payment_info, status, winning_spot_number, winning_instagram_handle, instagram_media_links, archived, created_at, completed_at, item_count, winning_spot_numbers, winning_instagram_handles) FROM stdin;
f1d6f95c-972b-4393-a0fe-70ab7bea71fa	welcome-example-waffle	Example Waffle	Welcome! This is an example waffle showing how spots work. Feel free to delete it and create your own.	\N	10	500	\N	active	\N	\N	[]	f	2026-05-31 05:10:45.34466+00	\N	1	[]	[]
183bf8c4-5793-4401-be77-1ab355eca74e	clearwinner-test-waffle-d014294d	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-05-31 08:35:34.407377+00	\N	1	[]	[]
f258f9ba-41a0-4aa9-8d2f-74652b159932	active-test-waffle-4eda131f	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 08:35:34.47056+00	\N	1	[]	[]
6d659823-d579-4a38-a649-12bb02c3e402	active-test-waffle-98103925	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 12:57:24.232291+00	\N	1	[]	[]
9cc5a5dc-a470-469e-84a9-67e1bb3accce	active-test-waffle-2dd7e17d	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 08:35:34.531115+00	\N	1	[]	[]
43e44a34-ee1b-4341-a027-5e889f34fcc0	clearwinner-test-waffle-8b5f108f	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-05-31 09:55:13.612543+00	\N	1	[]	[]
f149228e-3780-4f2f-aab2-1775a1fecdcf	active-test-waffle-fa17d351	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 09:55:13.837618+00	\N	1	[]	[]
439043a0-28ca-4b4e-9869-e0c19bafae22	active-test-waffle-af298dc0	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 09:55:13.901033+00	\N	1	[]	[]
01cacd0e-cf0e-4fda-b6f3-70bf44f0c316	clearwinner-test-waffle-fbe2d297	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-05-31 12:38:54.129498+00	\N	1	[]	[]
7ef62753-923b-4953-97c9-1d6f868d5b8c	active-test-waffle-7340254f	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 12:38:54.214399+00	\N	1	[]	[]
e9b10c7a-155a-426c-b44a-319cb51784af	active-test-waffle-4767bbf0	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 12:38:54.303048+00	\N	1	[]	[]
70bfdcd5-1290-4895-8439-d8da599d2559	clearwinner-test-waffle-2c20e0d3	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-05-31 12:57:24.094328+00	\N	1	[]	[]
d0f59974-bf19-4d6c-bce4-d3d20bb88307	active-test-waffle-3ea48320	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 12:57:24.166127+00	\N	1	[]	[]
8a93df0d-9d96-4c61-8f7c-c8cccbdf18a0	clearwinner-test-waffle-0d9867e5	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-05-31 15:55:26.979569+00	\N	1	[]	[]
1bb09252-93c6-4638-a8e6-bb5141d3b004	active-test-waffle-69fca65a	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 15:55:27.097108+00	\N	1	[]	[]
e75295e4-4972-48d9-a2b6-8fcf91af134a	active-test-waffle-df0d434a	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 15:55:27.18544+00	\N	1	[]	[]
90de122b-7663-4d06-8d3b-6551edf71998	clearwinner-test-waffle-fba47e61	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-05-31 16:01:03.136101+00	\N	1	[]	[]
795d39b1-fed0-4b15-87ef-e6cde159a1ba	active-test-waffle-f04442e3	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 16:01:03.260692+00	\N	1	[]	[]
7d9fdd9a-b84c-4e95-a568-51f1439d92d6	active-test-waffle-a7202a55	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-05-31 16:01:03.368566+00	\N	1	[]	[]
6c01d7f8-3580-47f4-af2d-afd96d94e3fa	clearwinner-test-waffle-a1b9e9a7	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-06-04 06:35:29.563174+00	\N	1	[]	[]
2e190df7-b395-42f0-9865-2e2a34b0421d	active-test-waffle-965e41c2	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-06-04 06:35:29.608783+00	\N	1	[]	[]
5221719c-43f9-45ea-b7eb-e421f8aea70c	active-test-waffle-247c9770	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-06-04 06:35:29.655651+00	\N	1	[]	[]
9c8c96ba-da01-4a5e-8111-67559da47f15	clearwinner-test-waffle-ab8bfe1a	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-05-31 12:57:24.177128+00	2026-05-31 12:57:24.203833+00	1	[5]	["buyer_b"]
b760eecb-035c-479f-bfcd-61adf24376bf	clearwinner-test-waffle-7598efa7	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-05-31 08:35:34.478987+00	2026-05-31 08:35:34.503557+00	1	[5]	["buyer_b"]
1c085be0-7d56-46da-b681-bf2973ca64ec	clearwinner-test-waffle-cb54a2da	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-05-31 08:35:34.53952+00	2026-05-31 08:35:34.563644+00	1	[3]	["buyer_a"]
bd600a4a-416d-4515-87c4-2beb9ad65844	clearwinner-test-waffle-6dc15633	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-05-31 12:57:24.239519+00	2026-05-31 12:57:24.258267+00	1	[3]	["buyer_a"]
1ad9926e-f4b2-4371-8700-4eac8db8c58e	clearwinner-test-waffle-cfc96788	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-05-31 09:55:13.852803+00	2026-05-31 09:55:13.880466+00	1	[5]	["buyer_b"]
5fdaa77b-7aea-47ef-9739-64c67c4689c7	clearwinner-test-waffle-38a7e5d4	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-05-31 09:55:13.906653+00	2026-05-31 09:55:13.924083+00	1	[3]	["buyer_a"]
e829e15b-906a-4565-a701-fadc88a0269f	clearwinner-test-waffle-4b883934	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-05-31 12:38:54.22688+00	2026-05-31 12:38:54.264063+00	1	[5]	["buyer_b"]
04286455-e723-4d19-b3c4-7b52114fa750	clearwinner-test-waffle-8149a4a6	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-05-31 12:38:54.313266+00	2026-05-31 12:38:54.351952+00	1	[3]	["buyer_a"]
63abf727-159b-4a26-aa35-f6a49e70e5da	clearwinner-test-waffle-da59a373	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-05-31 15:55:27.109635+00	2026-05-31 15:55:27.144661+00	1	[5]	["buyer_b"]
cfb15ed5-49f3-412d-a947-dc5ee49c63d2	clearwinner-test-waffle-1199889a	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-05-31 15:55:27.195025+00	2026-05-31 15:55:27.228005+00	1	[3]	["buyer_a"]
6237a959-8703-4691-a06a-fa4a2509246e	clearwinner-test-waffle-b8d0886b	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-05-31 16:01:03.276426+00	2026-05-31 16:01:03.318901+00	1	[5]	["buyer_b"]
a75f0133-008a-4ff0-a70e-270375cea185	clearwinner-test-waffle-f5a4b798	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-05-31 16:01:03.385146+00	2026-05-31 16:01:03.420792+00	1	[3]	["buyer_a"]
f1e823df-265b-46ca-9ca8-6d8977e332b4	clearwinner-test-waffle-c72d433f	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-06-04 06:35:29.614724+00	2026-06-04 06:35:29.630661+00	1	[5]	["buyer_b"]
2f308ab1-2528-454f-99db-758f8e02f3f3	clearwinner-test-waffle-36e53cf4	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-06-04 06:35:29.661272+00	2026-06-04 06:35:29.678114+00	1	[3]	["buyer_a"]
6c2b3769-756c-4a9e-93f0-ef41a79953ac	clearwinner-test-waffle-a0e89903	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-06-04 07:36:53.717184+00	\N	1	[]	[]
771d423f-7e7f-4b92-9040-4f07e3419368	active-test-waffle-bc5a4ef3	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-06-04 07:36:53.789874+00	\N	1	[]	[]
80b4aa08-2c80-4a4c-ab7a-6856df44077c	clearwinner-test-waffle-928a9bee	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-06-04 07:36:53.804788+00	2026-06-04 07:36:53.832004+00	1	[5]	["buyer_b"]
11e1a13d-4d7d-4173-a559-0c652258a6c9	active-test-waffle-e92e98ed	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-06-04 07:36:53.867702+00	\N	1	[]	[]
7f74e30d-cbf8-473a-a8f1-f223a7dc7698	clearwinner-test-waffle-cc505d9a	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-06-04 07:36:53.877566+00	2026-06-04 07:36:53.906513+00	1	[3]	["buyer_a"]
c3d90fb2-2cea-4c3d-a0b8-baf8f83eaf7b	multi-item-example-waffle	Multi-Item Example Waffle	Welcome! This is an example waffle with 3 items up for grabs, each with its own Instagram post.	\N	10	1000	\N	active	\N	\N	["https://www.instagram.com/p/C-example1/", "https://www.instagram.com/p/C-example2/", "https://www.instagram.com/p/C-example3/"]	f	2026-06-04 07:43:59.758126+00	\N	3	[]	[]
fc30b295-0f06-4b2a-9da8-ef1cfb4cc5cc	clearwinner-test-waffle-91292a75	ClearWinner Test Waffle	\N	\N	5	10	\N	active	\N	\N	\N	f	2026-06-04 07:37:38.715314+00	\N	1	[]	[]
abe882bc-df15-4881-9b02-7e046d738a6a	active-test-waffle-4b2d4457	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-06-04 07:37:38.790312+00	\N	1	[]	[]
207508f1-9de3-4c88-b4c3-d89e2dd65ebb	clearwinner-test-waffle-f1f2fbf8	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	5	buyer_b	\N	f	2026-06-04 07:37:38.801191+00	2026-06-04 07:37:38.830064+00	1	[5]	["buyer_b"]
dd8a7229-df0b-462d-a4b9-670501b1d243	active-test-waffle-394e0ffc	Active Test Waffle	\N	\N	3	5	\N	active	\N	\N	\N	f	2026-06-04 07:37:38.862333+00	\N	1	[]	[]
24651645-3d0d-4d1c-91b1-d2fc4e39733d	clearwinner-test-waffle-47ed4b37	ClearWinner Test Waffle	\N	\N	5	10	\N	completed	3	buyer_a	\N	f	2026-06-04 07:37:38.87168+00	2026-06-04 07:37:38.893898+00	1	[3]	["buyer_a"]
\.


--
-- Name: activity_events activity_events_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_pkey PRIMARY KEY (id);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: admins admins_username_key; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_username_key UNIQUE (username);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: buyer_stats buyer_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.buyer_stats
    ADD CONSTRAINT buyer_stats_pkey PRIMARY KEY (instagram_handle);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: spots spots_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.spots
    ADD CONSTRAINT spots_pkey PRIMARY KEY (id);


--
-- Name: spots spots_waffle_id_number_key; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.spots
    ADD CONSTRAINT spots_waffle_id_number_key UNIQUE (waffle_id, number);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: users users_instagram_handle_key; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_instagram_handle_key UNIQUE (instagram_handle);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: waffles waffles_pkey; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.waffles
    ADD CONSTRAINT waffles_pkey PRIMARY KEY (id);


--
-- Name: waffles waffles_slug_key; Type: CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.waffles
    ADD CONSTRAINT waffles_slug_key UNIQUE (slug);


--
-- Name: admins_email_key; Type: INDEX; Schema: public; Owner: syrup
--

CREATE UNIQUE INDEX admins_email_key ON public.admins USING btree (email) WHERE (email IS NOT NULL);


--
-- Name: idx_admins_email; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_admins_email ON public.admins USING btree (email);


--
-- Name: idx_admins_username; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_admins_username ON public.admins USING btree (username);


--
-- Name: idx_audit_log_action_created_at; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_audit_log_action_created_at ON public.audit_log USING btree (action, created_at DESC);


--
-- Name: idx_audit_log_admin_id_created_at; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_audit_log_admin_id_created_at ON public.audit_log USING btree (admin_id, created_at DESC);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_login_history_admin_id_created_at; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_login_history_admin_id_created_at ON public.login_history USING btree (admin_id, created_at DESC);


--
-- Name: idx_login_history_created_at; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_login_history_created_at ON public.login_history USING btree (created_at DESC);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: idx_users_instagram_handle; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_users_instagram_handle ON public.users USING btree (instagram_handle);


--
-- Name: idx_waffles_archived; Type: INDEX; Schema: public; Owner: syrup
--

CREATE INDEX idx_waffles_archived ON public.waffles USING btree (archived);


--
-- Name: activity_events activity_events_waffle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.activity_events
    ADD CONSTRAINT activity_events_waffle_id_fkey FOREIGN KEY (waffle_id) REFERENCES public.waffles(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: login_history login_history_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: spots spots_waffle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.spots
    ADD CONSTRAINT spots_waffle_id_fkey FOREIGN KEY (waffle_id) REFERENCES public.waffles(id) ON DELETE CASCADE;


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: syrup
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.admins(id);


--
-- PostgreSQL database dump complete
--

\unrestrict u0n6Mj7JYZMm6dJ7bVQNkSF35heyaC1wjTvXuxwaXLmHdQWdStMk1EBCrh7a9dC

